<?php 
error_reporting(0);
session_start();
  $hostname="localhost";
  $username="root";
  $password="";
  $dbname="crane";
  $con=Mysqli_Connect($hostname,$username,$password,$dbname);

  if(!$con)
  {
	  die("connection not establish".mysqli_connect_error());
	  
  }

?>