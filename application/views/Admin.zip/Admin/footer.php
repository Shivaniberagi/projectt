 
 	           </div>
            <!-- end chat sidebar -->
        </div>
        <!-- end page container -->
 <!-- start footer -->
        <div class="page-footer">
            <div class="page-footer-inner"> 2017 &copy; Citiyano De Solutiions  Developed By
            <a href="#" target="_top"> Prads Software</a>
            </div>
            <div class="scroll-to-top">
                <i class="icon-arrow-up"></i>
            </div>
        </div>
        <!-- end footer -->
    </div>
    <script src="<?php echo base_url(); ?>/Admin/js/jquery.min.js" type="text/javascript"></script>
    <script src="<?php echo base_url(); ?>/Admin/js/bootstrap/js/bootstrap.min.js" type="text/javascript"></script>
    <script src="<?php echo base_url(); ?>/Admin/js/jquery.blockui.min.js" type="text/javascript"></script>
    <script src="<?php echo base_url(); ?>/Admin/js/bootstrap-switch/js/bootstrap-switch.min.js" type="text/javascript"></script>
    <script src="<?php echo base_url(); ?>/Admin/js/counterup/jquery.waypoints.min.js" type="text/javascript"></script>
    <script src="<?php echo base_url(); ?>/Admin/js/counterup/jquery.counterup.min.js" type="text/javascript"></script>
    <script src="<?php echo base_url(); ?>/Admin/js/jquery.slimscroll.js"></script>
    <script src="<?php echo base_url(); ?>/Admin/js/app.js" type="text/javascript"></script>
    <script src="<?php echo base_url(); ?>/Admin/js/layout.js" type="text/javascript"></script>
    <script src="<?php echo base_url(); ?>/Admin/js/chart-js/Chart.bundle.js" type="text/javascript"></script>
    <script src="<?php echo base_url(); ?>/Admin/js/chart-js/utils.js" type="text/javascript"></script>
    <script src="<?php echo base_url(); ?>/Admin/js/chart-js/home-data.js" type="text/javascript"></script>
    
    
  </body>

<!-- Mirrored from radixtouch.in/hospital/ by HTTrack Website Copier/3.x [XR&CO'2014], Mon, 18 Sep 2017 06:40:24 GMT -->
</html>